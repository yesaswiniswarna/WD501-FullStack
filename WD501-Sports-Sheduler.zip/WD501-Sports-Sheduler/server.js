const express = require("express");
const session = require("express-session");
const bcrypt = require("bcryptjs");
const pool = require("./database"); // Database configuration file
const app = express();

// Middleware setup
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static("public"));

// Session configuration
app.use(
  session({
    secret: "secret", // Replace with a secure secret in production
    resave: false,
    saveUninitialized: true,
  })
);

// View engine setup
app.set("view engine", "ejs");
app.set("views", __dirname + "/views");

// Authentication middleware
function isAuthenticated(req, res, next) {
  if (req.session.user) {
    req.user = req.session.user; // Make user accessible in req
    next();
  } else {
    res.redirect("/login");
  }
}

// Default route
app.get("/", (req, res) => {
  res.redirect("/dashboard");
});

// Login route
app.get("/login", (req, res) => {
  res.render("login");
});

app.post("/login", async (req, res) => {
  const { email, password } = req.body;
  try {
    const result = await pool.query("SELECT * FROM users WHERE email = $1", [email]);
    if (result.rows.length > 0) {
      const user = result.rows[0];
      const match = await bcrypt.compare(password, user.password);
      if (match) {
        req.session.user = { id: user.id, name: user.name, role: user.role };
        return res.redirect(user.role === "admin" ? "/admin-dashboard" : "/player-dashboard");
      }
    }
    res.status(401).send("Invalid email or password");
  } catch (error) {
    console.error("Error during login:", error);
    res.status(500).send("An error occurred during login");
  }
});

// Registration route
app.get("/register", (req, res) => {
  res.render("register");
});

app.post("/register", async (req, res) => {
  const { name, email, password, role } = req.body;
  try {
    const hashedPassword = await bcrypt.hash(password, 10);
    await pool.query(
      "INSERT INTO users (name, email, password, role) VALUES ($1, $2, $3, $4)",
      [name, email, hashedPassword, role]
    );
    res.redirect("/login");
  } catch (error) {
    console.error("Error during registration:", error);
    res.status(500).send("An error occurred during registration");
  }
});

// Dashboard route
app.get("/dashboard", isAuthenticated, (req, res) => {
  res.render("dashboard", { user: req.user });
});

// Admin dashboard route
app.get("/admin-dashboard", isAuthenticated, async (req, res) => {
  if (req.user.role !== "admin") return res.redirect("/dashboard");
  try {
    const sports = await pool.query("SELECT * FROM sports");
    const sessions = await pool.query(
      "SELECT sessions.*, sports.name AS sport_name, users.name AS creator_name " +
      "FROM sessions " +
      "JOIN sports ON sessions.sport_id = sports.id " +
      "JOIN users ON sessions.creator_id = users.id"
    );
    res.render("admin-dashboard", {
      user: req.user,
      sports: sports.rows,
      sessions: sessions.rows,
    });
  } catch (error) {
    console.error("Error loading admin dashboard:", error);
    res.status(500).send("Failed to load admin dashboard");
  }
});

// Create new sport
app.post("/create-sport", isAuthenticated, async (req, res) => {
  const { name } = req.body;
  try {
    await pool.query("INSERT INTO sports (name) VALUES ($1)", [name]);
    res.redirect("/admin-dashboard");
  } catch (error) {
    console.error("Error creating sport:", error);
    res.status(500).send("Failed to create sport");
  }
});

// Delete a sport
app.post("/delete-sport/:id", isAuthenticated, async (req, res) => {
  const sportId = req.params.id;
  try {
    await pool.query("DELETE FROM sports WHERE id = $1", [sportId]);
    res.sendStatus(200);
  } catch (error) {
    console.error("Error deleting sport:", error);
    res.status(500).send("Failed to delete sport");
  }
});

// Player dashboard route
app.get("/player-dashboard", isAuthenticated, async (req, res) => {
  try {
    const sessions = await pool.query(
      "SELECT sessions.*, sports.name AS sport_name " +
      "FROM sessions " +
      "JOIN sports ON sessions.sport_id = sports.id"
    );
    res.render("player-dashboard", {
      user: req.user,
      sessions: sessions.rows,
    });
  } catch (error) {
    console.error("Error loading player dashboard:", error);
    res.status(500).send("Failed to load player dashboard");
  }
});

// Logout route
app.get("/logout", (req, res) => {
  req.session.destroy(() => {
    res.redirect("/login");
  });
});

// Server setup
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
